#ifndef __SET_MOTOR_H
#define __SET_MOTOR_H	 
#include "sys.h" 
#include "stdlib.h"

void TIM9_CH1_PWM_Init(u16 arr,u16 psc);
void TIM9_CH2_PWM_Init(u16 arr,u16 psc);
//void TIM9_PWM_Init(u16 arr,u16 psc); 		
void SET_MOTOR_INIT(void);
void SET_MOTOR_DOWN_SPEED(int speed);
void SET_MOTOR_UP_SPEED(int speed);
#endif
