#include "include.h"

int8_t beep_init_flag=1;
int8_t beep_steep_flag=1;
int8_t start_flag=1;


//������ʼ������
void SWITCH_INIT(void)
{
	
	GPIO_InitTypeDef  GPIO_InitStructure;

  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOG, ENABLE);//ʹ��GPIOGʱ��
 
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2; //Switch0 Switch1 Switch2��Ӧ����
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//��ͨ����ģʽ
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100M
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
  GPIO_Init(GPIOG, &GPIO_InitStructure);
 
}

void SPTTER_BEEP_INIT()
{
		if((Switch0 != 0 || Switch1 != 0 || Switch2 != 0) && beep_init_flag==1)
		{
		//		GPIO_SetBits(GPIOB, GPIO_Pin_8);
		}
		else
		{
		//		GPIO_ResetBits(GPIOB, GPIO_Pin_8);
				delay_ms(1000);
				USART_CONTRAL(speed_up_stpeer,0,speed_left_right);
			  beep_steep_flag = 0;
		}
		
	
}








