#ifndef _FUZZY_H_
#define _FUZZY_H_

#include "math.h"
float ek_change(float x1 ,float x2);
float regression(int startline,int endline,float X[10]);
float Fuzzy_P(float P,float D);
float Fuzzy_I(float P,float D);
float Fuzzy_D(float P,float D);
#endif
