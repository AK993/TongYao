#include "up_motor.h"

int contral_speed_time = 0;

void TIM4_PWM_Init(u16 arr,u16 psc)
{		 					 
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);    
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE); 
	
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;	
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; 
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
	GPIO_Init(GPIOD,&GPIO_InitStructure); 
 
	
	GPIO_PinAFConfig(GPIOD,GPIO_PinSource12,GPIO_AF_TIM4); 

	
	
	TIM_TimeBaseStructure.TIM_Prescaler=psc;  //��ʱ����Ƶ
	TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up; //���ϼ���ģʽ
	TIM_TimeBaseStructure.TIM_Period=arr;   //�Զ���װ��ֵ
	TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1; 
	TIM_TimeBaseInit(TIM4,&TIM_TimeBaseStructure);


	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //�Ƚ����ʹ��
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //�������:TIM����Ƚϼ��Ը�
	TIM_OCInitStructure.TIM_Pulse=0;
	
	
	
	TIM_OC1Init(TIM4, &TIM_OCInitStructure);  
	TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable);  
 
 
 
  TIM_ARRPreloadConfig(TIM4,ENABLE);
	TIM_Cmd(TIM4, ENABLE);  
	
 					  
}  


/*  �����µ��IO�˿�ʹ�� �ϵ����ӦPD11,13��������  */

void UP_MOTOR_INIT(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;

  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);//


  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	
}


/*  �����ϵ���ٶȸ�ֵ */
void UP_MOTOR_UP_SPEED(int speed)
{
	int speed1;
	int speed2;
	contral_speed_time++;
	if(speed >= 0)
	{
		if(contral_speed_time<=15)
		{
			GPIO_SetBits(GPIOD, GPIO_Pin_13);
			GPIO_ResetBits(GPIOD, GPIO_Pin_11);
			TIM_SetCompare1(TIM4, speed);
		}
		else if(contral_speed_time>15&contral_speed_time<17)
		{
			//��תʱ����ȡ��
			speed2 = abs(speed);
			GPIO_ResetBits(GPIOD, GPIO_Pin_11);
			GPIO_ResetBits(GPIOD, GPIO_Pin_13);
			TIM_SetCompare1(TIM4, speed2);
		}
		else
		{
			//��תʱ����ȡ��
			speed1 = abs(speed/2);
			GPIO_SetBits(GPIOD, GPIO_Pin_11);
			GPIO_ResetBits(GPIOD, GPIO_Pin_13);
			TIM_SetCompare1(TIM4, speed1);
			if(contral_speed_time>18)contral_speed_time=0;
		}
			
	}
	else
	{
		//��תʱ����ȡ��
		speed = abs(speed);
		GPIO_SetBits(GPIOD, GPIO_Pin_11);
		GPIO_ResetBits(GPIOD, GPIO_Pin_13);
		TIM_SetCompare1(TIM4, speed);
	}
}

