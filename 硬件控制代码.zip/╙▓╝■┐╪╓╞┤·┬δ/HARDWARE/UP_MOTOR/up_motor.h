#ifndef __UP_MOTOR_H
#define __UP_MOTOR_H	 
#include "sys.h" 
#include "stdlib.h"


void TIM4_PWM_Init(u16 arr,u16 psc);	
void UP_MOTOR_INIT(void);
void UP_MOTOR_UP_SPEED(int speed);
#endif
