#ifndef __ALL_INIT_H
#define __ALL_INIT_H	 


void ALL_INIT(void);

#endif


